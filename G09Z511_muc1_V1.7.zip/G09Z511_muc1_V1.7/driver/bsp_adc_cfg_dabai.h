#ifndef _BSP_ADC_CFG_DABAI_H
#define _BSP_ADC_CFG_DABAI_H



// ======================= Configure =======================
// 配置：是否使用对应通道(1-使用；0-不使用)
#undef ADC_CFG_IS_USE_AIN2
#define ADC_CFG_IS_USE_AIN2            1
#undef ADC_CFG_IS_USE_AIN3
#define ADC_CFG_IS_USE_AIN3            1
#undef ADC_CFG_IS_USE_AIN4
#define ADC_CFG_IS_USE_AIN4            1
#undef ADC_CFG_IS_USE_AIN5
#define ADC_CFG_IS_USE_AIN5            1


#endif
/***************************** (END OF FILE) *********************************/
