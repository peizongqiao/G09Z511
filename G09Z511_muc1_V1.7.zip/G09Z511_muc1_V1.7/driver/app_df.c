#include "app_softtimer.h"
#include "app_log.h"
#include "bsp_pi_api.h"
#include "bsp_filtermotor_soft_subdivision.h"
#include "i2c_slave_N32G43X.h"



extern uint8_t flag_df;
extern uint8_t DF_poll;
bool RecycleFlag_2 = false;
bool RecycleFlag_1 = false;
extern uint16_t df_step;
bool status_1;
bool df_flag_go;
uint16_t RcycleCnt_filter = 0;
uint16_t FILTER_CLOSE = 0;
uint16_t FLAG_OPEN = 0;
bool flag = 0;
uint16_t filter_step_close=0;
uint16_t filter_step_number=0;
uint16_t filter_step=0;
uint16_t filter_step_half=0;
uint16_t flag_half=0;
uint16_t filter_step_open=0;
uint16_t filter_reset_step;
extern uint8_t FILTER_PI;
uint16_t filtertes_flag;
uint8_t filtertest;
uint16_t filter_step_1 = 0;

void filter_res()
{
	if(FILTER_PI==1)
	{
		filter_reset_step = 3600;
	}
}
void filter_ctrl_poll(void)
{
	if(DF_poll==1||flag_df==1)//K24
	{
		flag_df=0;
		filter_reset_step = 0;
		DF_poll=0;
		filter_step_1=0;
		filter_reset_step=0;
		df_flag_go = 0;
		filter_step_close = 0;
		filter_step=3600;
	}
	if(DF_poll==2)//K24
	{
		DF_poll=0;
		filter_reset_step = 0;
		filter_step_1=0;
		filter_reset_step=0;
		df_flag_go = 1;
		filter_step_close=df_step;
	}
	if(DF_poll == 3)//(2.3<Key) && (Key<2.5)K23
	{
		DF_poll=0;
		filter_reset_step = 0;
		filter_step_1=0;
		filter_reset_step=0;
		df_flag_go = 0;
		filter_step=df_step;
	}
	if(DF_poll == 4)//��ͣ
	{
		DF_poll=0;
		filter_reset_step = 0;
		filter_step_1=0;
		filter_reset_step=0;
		filter_step_close = 0;
		filter_step = 0; 
	}
	if(DF_poll == 5||flag_df==2)//(2.3<Key) && (Key<2.5)K23
	{
		flag_df = 0;
		filter_reset_step = 0;
		DF_poll=0;
		filter_step_1=0;
		filter_reset_step=0;
		df_flag_go = 1;
		filter_step=3600;
		filter_step_close=3600;
	}
	if(DF_poll == 6||flag_df==3)
	{
		flag_df=0;
		filter_reset_step = 0;
		filter_step_1=0;
		DF_poll=0;
		filter_reset_step=0;
		df_flag_go = 1;
		filter_step=3600;
		filter_step_close=2360;
	}
	if(flag_df==6)
	{
		filter_reset_step = 0;
		flag_df=0;
		filtertes_flag = 0;
		filtertest = 0;
		filter_step_1=3600;
	}
}

void filter_poll()
{
	if((df_flag_go==0&&FILTER_PI == 0))
	{
		
		bsp_filtermotor_api_stop();
		filter_step_number= 0;
		status_1 = 1;
		filter_step = 0;
		df_flag_go = 1;
	}
	else if(filter_step!=0)//K23
	{
		bsp_filtermotor_api_run(19000, 1, E_DIRECT_CLOSE);
		status_1 = 0;
		filter_step--;
		filter_step_number--;
		df_flag_go=0;
		if(filter_step_number>3600)
			filter_step_number = 0;
	}
	else if(filter_step_close!=0&&filter_step_number<3600)//K24
	{
		bsp_filtermotor_api_run(19000, 1, E_DIRECT_OPEN);
		status_1 = 0;
		filter_step_close--;
		filter_step_number++;
	}
	else 
		status_1 = 1;
}

void filter_poll_reset()
{
	if(filter_reset_step!=0&&FILTER_PI == 1)
	{
		bsp_filtermotor_api_run(19000, 1, E_DIRECT_CLOSE);
	}
    else if(FILTER_PI == 0)
	{
		filter_reset_step = 0;
		bsp_filtermotor_api_stop();
	}
}

void old()
{
	if(flag_df==4){// OLD
		flag_df=0;
		RecycleFlag_1 = false;
		RecycleFlag_2 = true;
	}
	if (flag_df==5) // Manual
	{
		flag_df=0;
		bsp_filtermotor_api_stop();
		RecycleFlag_1 = false;
		RecycleFlag_2 = false;
	}	
	if (flag_df==7) // Manual
	{
		flag_df=0;
		RecycleFlag_2 = false;
		RecycleFlag_1 = true;
	}
}

bool DIR = 0;
void filter_oold_poll()
{
	if(RecycleFlag_2 == true)
	{
		if(RcycleCnt_filter < 3560)
			{
				RcycleCnt_filter++;
			}
			else
			{				
				RcycleCnt_filter = 0;
				if(DIR==0)
					DIR=1;
				else
					DIR=0;
			}
			bsp_filtermotor_api_run(19000,1,DIR);
	}
}

void filter_test()
{
	if(filter_step_1>1)
	{
		bsp_filtermotor_api_run(10000,1,E_DIRECT_OPEN);
		filter_step_1--;
		filtertest = 1;
	}
	else if(FILTER_PI==0)
	{
		filter_step_1=0;
		filtertest = 3;
	}
	if(filter_step_1==1&&FILTER_PI==1&&filtertes_flag<5000)
	{
		bsp_filtermotor_api_run(10000,1,E_DIRECT_CLOSE);
		filtertes_flag++;
		filtertest = 1;
	}
	else if(filtertes_flag>3350&&filtertes_flag<3650)
	{
		filtertest = 2;
	}
	else if(filtertes_flag>=3650)
		filtertest = 3;
}


uint16_t RcycleCnt_filter_1;
uint16_t RcycleCnt_filter_2;
uint16_t RcycleCnt_filter_3;
uint16_t step_1;
uint16_t df_flag;
uint32_t count_filter;
void df_count()
{
	if(RecycleFlag_1)
	{
		count_filter++;
		if(count_filter==1)
		{
			step_1 = 2360;
			df_flag=1;
		}
		if(count_filter==180000)
		{
			step_1 = 1200;
			df_flag=2;
		}
		if(count_filter==360000)
		{
			step_1 = 3560;
			df_flag=3;
		}
		if(count_filter>540000)
		{
			count_filter=0;
			df_flag=0;
		}
	}
}
void filter_old_poll()//500us
{
	if(df_flag==1)
	{
		if(RcycleCnt_filter_1 < step_1)
			{
				RcycleCnt_filter_1++;
				bsp_filtermotor_api_run(19000,1,E_DIRECT_OPEN);
			}
			else
			{				
				bsp_filtermotor_api_stop();
			}
	}
	else if(df_flag==2)
	{
		if(RcycleCnt_filter_2 < step_1)
			{
				RcycleCnt_filter_2++;
				bsp_filtermotor_api_run(19000,1,E_DIRECT_OPEN);
			}
			else
			{				
				bsp_filtermotor_api_stop();
			}
	}
	else if(df_flag==3)
	{
		if(RcycleCnt_filter_3 < 3560)
			{
				RcycleCnt_filter_3++;
				bsp_filtermotor_api_run(19000,1,E_DIRECT_CLOSE);
			}
			else
			{				
				bsp_filtermotor_api_stop();
			}
	}
	else if(df_flag==0)
	{
		RcycleCnt_filter_1=0;
		RcycleCnt_filter_2=0;
		RcycleCnt_filter_3=0;
	}

}


