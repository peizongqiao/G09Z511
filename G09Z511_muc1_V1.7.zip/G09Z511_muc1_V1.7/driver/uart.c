#include "main.h"
#include "app_focal_ctrl.h"
#include "bsp_focal_dz24.h"
#include "app_softtimer.h"
#include "app_log.h"
#include "bsp_pi_api.h"
#include "dlp_manager.h"
#include "i2c_slave_N32G43X.h"

uint8_t reture_date[10];
uint16_t log_step,log_pps; 
uint16_t absolutely_step,focal_mode = 0;
//uint16_t flag;
uint16_t send[1];
extern uint8_t RxBuffer[15];
extern uint8_t log_number,log_flag;
bool df_switch;
bool flag_pps = 0;
uint8_t flag_df;
uint8_t temp_t;
uint8_t pwn_count;
uint16_t 	user_buf1[128];
uint8_t 	user_buf2[256];
uint32_t	addr;
extern int8_t tepm_DMD;
void foacl()
{
    if(log_flag==1)
    {
            if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)// aa 01 00 01 55 �����
            {	
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x00;
				i2c_write_block(0x02,2,0,d);
            }
            else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x02 && RxBuffer[4] ==0x55)//�ع��
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x01;
				i2c_write_block(0x02,2,0,d);
            }
            else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x03 && RxBuffer[4] ==0x55)//aa 03 00 01 55LOOK0
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x02;
				i2c_write_block(0x02,2,0,d);
            }
            else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x04 && RxBuffer[4] ==0x55)//aa 03 00 02 55LOOK11
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x03;
				i2c_write_block(0x02,2,0,d);
            }
            else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 03 00 03 55//LOOK2
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x04;
				i2c_write_block(0x02,2,0,d);
            }  
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 03 00 04 55LOOK3
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x05;
				i2c_write_block(0x02,2,0,d);
            }  
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x07 && RxBuffer[4] ==0x55)//aa 03 00 05 55LOOK4
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x06;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x08 && RxBuffer[4] ==0x55)//aa 03 00 06 55//LOOK5
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x07;
				i2c_write_block(0x02,2,0,d);
            }  
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x09 && RxBuffer[4] ==0x55)//aa 03 00 07 55//LOOK6
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x08;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x0A && RxBuffer[4] ==0x55)//aa 03 00 08 55//LOOK7
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x09;
				i2c_write_block(0x02,2,0,d);
            }
			
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x02 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x0B && RxBuffer[4] ==0x55)//aa 03 00 08 55//LOOK7
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x2A;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x03 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)//aa 03 00 09 55LOOK8
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x0A;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x03 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x02 && RxBuffer[4] ==0x55)//aa 03 00 0a 55//LOOK9
            {
				uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x0B;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x03 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x03 && RxBuffer[4] ==0x55)//aa 08 00 01 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x0C;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x03 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 02 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x0D;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x03 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x07 && RxBuffer[4] ==0x55)//aa 08 00 03 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x0E;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x03 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x08 && RxBuffer[4] ==0x55)//aa 08 00 04 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x0F;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)//aa 08 00 06 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x10;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x02 && RxBuffer[4] ==0x55)//aa 08 00 07 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x11;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x03 && RxBuffer[4] ==0x55)//aa 08 00 08 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x12;
				i2c_write_block(0x02,2,0,d);           
			}
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x04 && RxBuffer[4] ==0x55)//aa 08 00 09 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x13;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x14;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)//aa 08 00 06 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x15;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x02 && RxBuffer[4] ==0x55)//aa 08 00 07 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x16;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x03 && RxBuffer[4] ==0x55)//aa 08 00 08 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x17;
				i2c_write_block(0x02,2,0,d);            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x04 && RxBuffer[4] ==0x55)//aa 08 00 09 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x18;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x19;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x02;	
				d[1] = 0x01;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x07 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x02;	
				d[1] = 0x02;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x08 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x02;	
				d[1] = 0x03;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x09 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x02;	
				d[1] = 0x04;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x0A && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x02;	
				d[1] = 0x05;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x05 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x00 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x1A;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x05 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x00 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x1B;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x1C;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x1D;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x1E;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x1F;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x03 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x20;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x03 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x21;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x0A && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x03;	
				d[1] = 0x22;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x22;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x02 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x23;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x03 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x24;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x04 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x25;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x40;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x41;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x07 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x26;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x08 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x37;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x08 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x09 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x60;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x09 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x00 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				flag_df = 1;
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x09 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				flag_df = 2;
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x09 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x02 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				flag_df = 3;
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x07 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x2B;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x08 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x2C;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x07 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x2D;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x08 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x2E;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x03 && RxBuffer[3] ==0x07 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x2F;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x03 && RxBuffer[3] ==0x08 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x30;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x09 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x31;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x0A && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x32;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x09 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x33;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x0A && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x34;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x03 && RxBuffer[3] ==0x09 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x35;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x03 && RxBuffer[3] ==0x0A && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x01;	
				d[1] = 0x36;
				i2c_write_block(0x02,2,0,d);
            }

			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x0C && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x07;	
				d[1] = 0x1C;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x0D && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x07;	
				d[1] = 0x1D;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x0C && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x07;	
				d[1] = 0x2C;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x0D && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x07;	
				d[1] = 0x2D;
				i2c_write_block(0x02,2,0,d);
            }	
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x03 && RxBuffer[3] ==0x0C && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x07;	
				d[1] = 0x3C;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x07 && RxBuffer[2] == 0x03 && RxBuffer[3] ==0x0D && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
                uint8_t d[2];
				d[0] = 0x07;	
				d[1] = 0x3D;
				i2c_write_block(0x02,2,0,d);
            }				
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x09 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x03 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				flag_df=4;
            }	
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x09 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x04 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				flag_df=5;
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x09 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x07 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				flag_df=7;
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x09 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				df_switch=1;
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x09 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				df_switch=0;
            }			
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x01 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x00 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				uint8_t d[2];
				d[0] = 0x02;	
				d[1] = 0x10;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x01 && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				uint8_t d[2];
				d[0] = 0x02;	
				d[1] = 0x11;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x0B && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				uint8_t d[2];
				d[0] = 0x0B;	
				d[1] = 0x01;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x0B && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x02 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				uint8_t d[2];
				d[0] = 0x0B;	
				d[1] = 0x02;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x0B && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x03 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				uint8_t d[2];
				d[0] = 0x0B;	
				d[1] = 0x03;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x0B && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x04 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				uint8_t d[2];
				d[0] = 0x0B;	
				d[1] = 0x04;
				i2c_write_block(0x02,2,0,d);
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x0B && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x05 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				flag_df = 6;
            }
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x0A && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x00 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				pwn_count = Flash_Read(0x08017000);
				TIM4->CCDAT1=++pwn_count;
				addr = FLASH_WRITE_START_ADDR;
				memset(user_buf2, 0xa1, 256);
				user_buf2[0] = pwn_count;
				FLASH_Program_User(addr, user_buf2, 256);	//��0x08010000��ʼ��ַд256�ֽ�
            }
			
			else if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x0A && RxBuffer[2] == 0x00 && RxBuffer[3] ==0x01 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
            {
				pwn_count = Flash_Read(0x08017000);
				TIM4->CCDAT1=--pwn_count;
				addr = FLASH_WRITE_START_ADDR;
				memset(user_buf2, 0xa1, 256);
				user_buf2[0] = pwn_count;
				FLASH_Program_User(addr, user_buf2, 256);	//��0x08010000��ʼ��ַд256�ֽ�
            }
		if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x01 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
		{
			tepm_DMD = Flash_Read(0x080179FF);
			tepm_DMD = tepm_DMD+1;
			addr = 0x080179FF;
			memset(user_buf2, 0xa1, 256);
			user_buf2[0] = tepm_DMD;
			FLASH_Program_User(addr, user_buf2, 256);	//��0x08010000��ʼ��ַд256�ֽ�
		}
		if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x06 && RxBuffer[4] ==0x55)//aa 08 00 0a 55
		{
			tepm_DMD = Flash_Read(0x080179FF);
			tepm_DMD = tepm_DMD-1;
			addr = 0x080179FF;
			memset(user_buf2, 0xa1, 256);
			user_buf2[0] = tepm_DMD;
			FLASH_Program_User(addr, user_buf2, 256);	//��0x08010000��ʼ��ַд256�ֽ�
		}
		if(RxBuffer[0] ==0xaa && RxBuffer[1] == 0x04 && RxBuffer[2] == 0x02 && RxBuffer[3] ==0x0B && RxBuffer[4] ==0x55)//aa 08 00 0a 55
		{
			addr = 0x080179FF;
			memset(user_buf2, 0xa1, 256);
			user_buf2[0] = 0;
			FLASH_Program_User(addr, user_buf2, 256);	//��0x08010000��ʼ��ַд256�ֽ�
		}
		 I2C2_GPIO_init();
         USART_ConfigInt(UART4 , USART_INT_RXDNE, ENABLE);
        }
         log_flag = 0;
}