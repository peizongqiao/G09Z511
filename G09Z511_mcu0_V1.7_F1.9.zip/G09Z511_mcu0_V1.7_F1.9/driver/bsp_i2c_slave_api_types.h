#ifndef BSP_I2C_SLAVE_API_TYPES_H
#define BSP_I2C_SLAVE_API_TYPES_H

#include "GMtypes.h"



typedef void(*i2c_slave_callback_t)(void);



#endif