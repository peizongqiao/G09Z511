/*
* 模块名称 : 步进电机驱动参数配置（DABAI项目类型）
* 文件名称 : xxxxx.c
* 说     明 :
*
*/
#ifndef BSP_FILTERMOTOR_SOFT_SUBDIVISION_CFG_DABAI_H_
#define BSP_FILTERMOTOR_SOFT_SUBDIVISION_CFG_DABAI_H_

//#include "port.h"
#include "n32g43x_start_pins.h"

//======================= configure ========================







#endif
