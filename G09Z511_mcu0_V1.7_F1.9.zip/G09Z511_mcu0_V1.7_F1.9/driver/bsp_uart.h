/*
* 模块名称 :uart驱动
* 文件名称 :xxxxx.h
* 说    明 :目前只是支持单路配置。
*
*/
#ifndef _BSP_UART_H_
#define _BSP_UART_H_


#include "bsp_uart_cfg.h"


// ======================== external ========================
void bsp_uart_api_init(void);



#endif